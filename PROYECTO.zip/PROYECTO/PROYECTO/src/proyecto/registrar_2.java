/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyecto;

import java.applet.AudioClip;
import java.sql.*;
import java.util.*;
import javax.swing.JOptionPane;

public class registrar_2 extends javax.swing.JFrame {

    public registrar_2() {
        initComponents();
        transparenciaButton();
        setLocationRelativeTo(null);
        txtId.setVisible(false);
    }

    public void transparenciaButton() {
        btnRegistrar.setOpaque(false);
        btnRegistrar.setContentAreaFilled(false);
        btnRegistrar.setBorderPainted(false);
        btnBuscar.setOpaque(false);
        btnBuscar.setContentAreaFilled(false);
        btnBuscar.setBorderPainted(false);
        btnLimpiar.setOpaque(false);
        btnLimpiar.setContentAreaFilled(false);
        btnLimpiar.setBorderPainted(false);
        jbtn_SALIR.setOpaque(false);
        jbtn_SALIR.setContentAreaFilled(false);
        jbtn_SALIR.setBorderPainted(false);
        btnLogin.setOpaque(false);
        btnLogin.setContentAreaFilled(false);
        btnLogin.setBorderPainted(false);
    }

    /*CONEXION A BASE DE DATOS*/
    public Connection Conectar() {
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/proyecto_poo?useSSL=false", "root", "");
        } catch (SQLException e) {
            System.err.print(e.toString());
            javax.swing.JOptionPane.showMessageDialog(this, "Ocurrio un error inesperado.\nFavor comunicarse con el administrador.");
        }
        return con;
    }

    AudioClip Sound;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtcodigo = new javax.swing.JTextField();
        txtusuario = new javax.swing.JTextField();
        btnRegistrar = new javax.swing.JButton();
        jbtn_SALIR = new javax.swing.JButton();
        btnLogin = new javax.swing.JButton();
        txtpuntaje = new javax.swing.JTextField();
        btnLimpiar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        txtId = new javax.swing.JTextField();
        contra = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtcodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcodigoActionPerformed(evt);
            }
        });
        getContentPane().add(txtcodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 150, 214, -1));

        txtusuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtusuarioActionPerformed(evt);
            }
        });
        getContentPane().add(txtusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 220, 214, -1));

        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, 120, 30));

        jbtn_SALIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtn_SALIRActionPerformed(evt);
            }
        });
        getContentPane().add(jbtn_SALIR, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 500, 90, 30));

        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });
        getContentPane().add(btnLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 500, 90, 30));

        txtpuntaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpuntajeActionPerformed(evt);
            }
        });
        getContentPane().add(txtpuntaje, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 360, 214, -1));

        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });
        getContentPane().add(btnLimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 430, 130, 30));

        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 430, 130, 30));

        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        getContentPane().add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 20, 59, -1));

        contra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contraActionPerformed(evt);
            }
        });
        getContentPane().add(contra, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 290, 214, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/REGISTRAR PROYECT.png"))); // NOI18N
        jLabel5.setText("jLabel5");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 545, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void limpiar() {
        txtcodigo.setText(null);
        txtusuario.setText(null);
        contra.setText(null);
        txtpuntaje.setText(null);
    }
    private void txtcodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcodigoActionPerformed

    private void txtusuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtusuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtusuarioActionPerformed

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        Sound = java.applet.Applet.newAudioClip(getClass().getResource("/SONIDOS/Boton.wav"));
        Sound.play();

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        if (txtcodigo.equals("") || txtusuario.equals("") || contra.equals("") || txtpuntaje.equals("")) {
            javax.swing.JOptionPane.showMessageDialog(this, "Uno o mas campos estan vacios. Favor de llenarlos.");
        } else {
            try {
                con = Conectar();
                pst = con.prepareStatement("INSERT INTO alumnos(Codigo,Usuario, Contraseña,Puntaje) VALUES(?,?,?,0)");
                pst.setString(1, txtcodigo.getText());
                pst.setString(2, txtusuario.getText());
                pst.setString(3, contra.getText());

                int res = pst.executeUpdate();
                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "Alumno registrado con exito");
                    limpiar();
                } else {
                    JOptionPane.showMessageDialog(null, "ERROR AL GUARDAR ALUMNO");
                    limpiar();
                }
                con.close();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "ERROR AL INSERTAR ALUMNO");
            }
        }
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void jbtn_SALIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtn_SALIRActionPerformed
        Sound = java.applet.Applet.newAudioClip(getClass().getResource("/SONIDOS/Click.wav"));
        Sound.play();

        int r = JOptionPane.showOptionDialog(this,
                "¿Estas seguro de salir...?",
                "Sistema medida de consumo",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null, null, null);
        if (r == 0)
            System.exit(0);
    }//GEN-LAST:event_jbtn_SALIRActionPerformed

    private void txtpuntajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpuntajeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpuntajeActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        Sound = java.applet.Applet.newAudioClip(getClass().getResource("/SONIDOS/Boton.wav"));
        Sound.play();

        limpiar();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        Sound = java.applet.Applet.newAudioClip(getClass().getResource("/SONIDOS/Boton.wav"));
        Sound.play();

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        if (txtcodigo.equals("") || txtusuario.equals("") || contra.equals("") || txtpuntaje.equals("")) {
            javax.swing.JOptionPane.showMessageDialog(this, "Uno o mas campos estan vacios. Favor de llenarlos.");
        } else {
            try {
                con = Conectar();
                pst = con.prepareStatement("SELECT*FROM alumnos WHERE codigo=?");
                pst.setString(1, txtcodigo.getText());
                rs = pst.executeQuery();
                if (rs.next()) {
                    txtId.setText(rs.getString("ID"));
                    txtusuario.setText(rs.getString("Usuario"));
                    contra.setText(rs.getString("Contraseña"));
                    txtpuntaje.setText(rs.getString("Puntaje"));
                } else {
                    JOptionPane.showMessageDialog(null, "El alumno no existe");
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "ERROR AL BUSCAR ALUMNO");
            }
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        Sound = java.applet.Applet.newAudioClip(getClass().getResource("/SONIDOS/Click.wav"));
        Sound.play();
        login_2 abrir = new login_2();
        abrir.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnLoginActionPerformed

    private void contraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contraActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(registrar_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(registrar_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(registrar_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(registrar_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registrar_2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnLogin;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JPasswordField contra;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JButton jbtn_SALIR;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtcodigo;
    private javax.swing.JTextField txtpuntaje;
    private javax.swing.JTextField txtusuario;
    // End of variables declaration//GEN-END:variables
}
