/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyecto;

import java.applet.AudioClip;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author crist
 */
public class p1 extends javax.swing.JFrame {

    public Connection Conectar() {
        Connection con = null;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/proyecto_poo?useSSL=false", "root", "");
        } catch (SQLException e) {
            System.err.print(e.toString());
            javax.swing.JOptionPane.showMessageDialog(this, "Ocurrio un error inesperado.\nFavor comunicarse con el administrador.");
        }
        return con;
    }

    public p1() {
        initComponents();
    }

    AudioClip Sound;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        txt_pregunta = new javax.swing.JTextField();
        txt_score = new javax.swing.JTextField();
        txtpuntaje = new javax.swing.JTextField();
        jbtnSiguiente = new javax.swing.JButton();
        jbtnC = new javax.swing.JButton();
        jbtnF2 = new javax.swing.JButton();
        jbtnF = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Ventana1");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/Zoomed in Photo of a Girl Couples Love Quote.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 30, 250, 140));

        txt_pregunta.setBackground(new java.awt.Color(209, 142, 41));
        txt_pregunta.setFont(new java.awt.Font("Ebrima", 1, 14)); // NOI18N
        txt_pregunta.setText("¿QUE ESCRITOR PERUANO GANO UN PREMIO NOBEL DE LITERATURA?");
        txt_pregunta.setBorder(new javax.swing.border.MatteBorder(null));
        txt_pregunta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_preguntaActionPerformed(evt);
            }
        });
        getContentPane().add(txt_pregunta, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, 520, 30));

        txt_score.setText("SCORE:");
        txt_score.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_scoreActionPerformed(evt);
            }
        });
        getContentPane().add(txt_score, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, -1, -1));

        txtpuntaje.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtpuntajeCaretUpdate(evt);
            }
        });
        txtpuntaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpuntajeActionPerformed(evt);
            }
        });
        getContentPane().add(txtpuntaje, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 20, 100, -1));

        jbtnSiguiente.setText("SIG");
        jbtnSiguiente.setToolTipText("");
        jbtnSiguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnSiguienteActionPerformed(evt);
            }
        });
        getContentPane().add(jbtnSiguiente, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 440, -1, -1));

        jbtnC.setText("Mario Vargas Llosa");
        jbtnC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnCActionPerformed(evt);
            }
        });
        getContentPane().add(jbtnC, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, 530, 50));

        jbtnF2.setText("Ricardo Palma");
        jbtnF2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnF2ActionPerformed(evt);
            }
        });
        getContentPane().add(jbtnF2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 380, 530, 50));

        jbtnF.setText("Cesar Vallejo");
        jbtnF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFActionPerformed(evt);
            }
        });
        getContentPane().add(jbtnF, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, 530, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/fondo.jpeg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt_preguntaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_preguntaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_preguntaActionPerformed

    private void jbtnCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnCActionPerformed
        Sound = java.applet.Applet.newAudioClip(getClass().getResource("/SONIDOS/Acierto.wav"));
        Sound.play();
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        Jugador ju = new Jugador();

        try {
            con = Conectar();
            pst = con.prepareStatement("UPDATE alumnos set Puntaje = Puntaje+1 WHERE Usuario = '" + ju.getJugador() + "'");
            int res = pst.executeUpdate();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "COMO ES POSIBLE DE ESTE SUCESO");
        }

        JOptionPane.showMessageDialog(null, "RESPUESTA CORRECTA");
        //PUNTAJE
        try {
            con = Conectar();
            pst = con.prepareStatement("SELECT*FROM alumnos WHERE Usuario = '" + ju.getJugador() + "'");
            rs = pst.executeQuery();
            if (rs.next()) {
                txtpuntaje.setText(rs.getString("Puntaje"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "COMO ES POSIBLE DE ESTE SUCESO");
        }
    }//GEN-LAST:event_jbtnCActionPerformed

    private void jbtnFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFActionPerformed
        Sound = java.applet.Applet.newAudioClip(getClass().getResource("/SONIDOS/Error.wav"));
        Sound.play();
        JOptionPane.showMessageDialog(null, "RESPUESTA INCORRECTA");
    }//GEN-LAST:event_jbtnFActionPerformed

    private void jbtnF2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnF2ActionPerformed
        Sound = java.applet.Applet.newAudioClip(getClass().getResource("/SONIDOS/Error.wav"));
        Sound.play();
        JOptionPane.showMessageDialog(null, "RESPUESTA INCORRECTA");
    }//GEN-LAST:event_jbtnF2ActionPerformed

    private void jbtnSiguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnSiguienteActionPerformed
        Sound = java.applet.Applet.newAudioClip(getClass().getResource("/SONIDOS/Siguiente.wav"));
        Sound.play();
        p2 abrir = new p2();
        abrir.setVisible(true);
        this.setVisible(false);


    }//GEN-LAST:event_jbtnSiguienteActionPerformed

    private void txt_scoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_scoreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_scoreActionPerformed

    private void txtpuntajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpuntajeActionPerformed


    }//GEN-LAST:event_txtpuntajeActionPerformed

    private void txtpuntajeCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtpuntajeCaretUpdate

    }//GEN-LAST:event_txtpuntajeCaretUpdate

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(p1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(p1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(p1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(p1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new p1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton jbtnC;
    private javax.swing.JButton jbtnF;
    private javax.swing.JButton jbtnF2;
    private javax.swing.JButton jbtnSiguiente;
    private javax.swing.JTextField txt_pregunta;
    private javax.swing.JTextField txt_score;
    private javax.swing.JTextField txtpuntaje;
    // End of variables declaration//GEN-END:variables
}
