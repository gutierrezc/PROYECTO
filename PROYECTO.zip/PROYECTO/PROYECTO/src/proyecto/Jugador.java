/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;


public class Jugador {
    public static String jugador =" ";

    public static String getJugador() {
        return jugador;
    }

    public static void setJugador(String jugador) {
        Jugador.jugador = jugador;
    } 
}
